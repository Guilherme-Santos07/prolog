:- load_files([aviao,
            bairro,
            cep,
            cidade,
            compra,
            compra_item,
            conjunto,
            etapa_peca,
            etapa_producao,
            fabrica,
            fornecedor,
            funcionario,
            grupo,
            logradouro,
            peca,
            pessoa,
            teste]).

%[
%              if(not_loaded), % só carrega o módulo uma vez
%                 silent(true) % carrega o módulo sem imprimir mensagem
%         ])
