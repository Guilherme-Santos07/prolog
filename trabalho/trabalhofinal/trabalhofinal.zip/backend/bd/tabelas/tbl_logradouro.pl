created(1660858911.67368).
assert(logradouro(4,'Carmo Gifoni',rua)).
