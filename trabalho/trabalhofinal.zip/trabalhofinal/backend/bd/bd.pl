%Guilherme dos Santos Silva - 12111BSI214
%Bernardo Hipolito Mundim Porto - 12111BSI219
%Joao Pedro Cruz Espindola - 12111BSI245
%Atilio de Melo Faria - 12111BSI233
%(O Atilio n�o esta mais conosco, ele saiu do curso, como ja haviamos
%come�ado o trabalho quando ele nos comunicou resolvemos continuar com
%essa monografia para quatro pessoas)

%Sistema de Gestao de Estoque e Producao da Fabrica Brasileira de
%Aeronaves [2008]

:- load_files([aviao,
            bairro,
            cep,
            cidade,
            compra,
            compra_item,
            conjunto,
            etapa_peca,
            etapa_producao,
            fabrica,
            fornecedor,
            funcionario,
            grupo,
            logradouro,
            peca,
            pessoa,
            teste]).
