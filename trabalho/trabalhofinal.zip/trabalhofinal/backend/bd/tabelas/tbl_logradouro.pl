created(1660848727.598403).
assert(logradouro(4,'Carmo Gifoni',rua)).
