created(1660848830.467409).
assert(cidade(2,'Udia','MG',34)).
