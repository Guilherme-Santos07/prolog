created(1660858911.676275).
assert(cidade(2,'Udia','MG',34)).
